// Vertical datatable headers with AJAX
$('.table-vertical-header').on('wb-updated.wb-tables', function (event, settings) {
	var $th = $('th');
	$('td').attr('data-header', function () {
		//When datatable has no results
		if ($('td').hasClass('dataTables_empty')) {
			return null;
		}

		return $th.eq($(this).index()).data('header');
	});

});
