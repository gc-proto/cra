	
	
$( ".table-row-group" ).on( "wb-ready.wb-tables", function( event ) {
 $.getScript( "/wet40/intranet/js/dataTables.rowGroup.min.js", function() {
	 $(".table-row-group").each(function(){
      var table = $(this).DataTable();
  new $.fn.dataTable.RowGroup(table);
tableCol = $(this).data("wb-tables");
var colData = tableCol.rowGroup.dataSrc;
var colOrder = tableCol.rowGroup.orderFixed;
var colClass = tableCol.rowGroup.className;
table.rowGroup().order.fixed({pre: [colOrder]}).dataSrc(colData).draw();
 $("tr.group").attr("aria-hidden","true").addClass(colClass);
		 $('.table-row-group').on('draw.dt', function () {

	$("tr.group").attr("aria-hidden", "true").addClass(colClass);

});
});
});
});